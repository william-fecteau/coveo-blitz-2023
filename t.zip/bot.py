from game_message import *
from actions import *


class Bot:
    def __init__(self):
        print("Initializing your super mega duper bot")

    def get_next_move(self, game_message: GameMessage):
        """
        Here is where the magic happens, for now the moves are not very good. I bet you can do better ;)
        """

        our_team_id = game_message.teamId
        other_team_ids = [team for team in game_message.teams if team != game_message.teamId]
        actions = list()
   

        curIndex = 0
        curTeam = 0

        if game_message.teamInfos[our_team_id].money >= 200:
            pathPos: Position = game_message.map.paths[0].tiles[curIndex]
            towerPos: Position = Position(pathPos.x + 1, pathPos.y + 1)
            actions.append(BuildAction(TowerType.SPEAR_SHOOTER, towerPos))
        else:
            actions.append(SendReinforcementsAction(EnemyType.LVL1, other_team_ids[curTeam % len(other_team_ids)]))
            curTeam += 1

        return actions

    def getNeighbours(self, pos: Position, range: int):
        neighbours = list()
        for x in range(-range, range + 1):
            for y in range(-range, range + 1):
                if x == 0 and y == 0:
                    continue
                neighbours.append(Position(pos.x + x, pos.y + y))
        return neighbours

