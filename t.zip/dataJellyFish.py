EnnemiStats = {
    "Ennemi": {
        "lvl1": {
            "speed": 1.0,
            "HP": 1,
            "maxHP":1
        },
        "lvl2": {
            "speed": 1.4,
            "HP": 2,
            "maxHP":3
        },
        "lvl3": {
            "speed": 1.8,
            "HP": 3,
            "maxHP":6
        },
        "lvl4": {
            "speed": 3.2,
            "HP": 4,
            "maxHP":10
        },
        "lvl5": {
            "speed": 3.5,
            "HP": 5,
            "maxHP":15
        },
        "lvl6": {
            "speed": 1.8,
            "HP": 10,
            "maxHP":40
        },
        "lvl7": {
            "speed": 2.0,
            "HP": 10,
            "maxHP":40
        },
        "lvl8": {
            "speed": 3.4,
            "HP": 10,
            "maxHP":40
        },
        "lvl9": {
            "speed": 1.8,
            "HP": 20,
            "maxHP":100
        },
        "lvl10": {
            "speed": 3.0,
            "HP": 20,
            "maxHP":100
        },
        "lvl11": {
            "speed": 1.8,
            "HP": 40,
            "maxHP":240
        },
        "lvl12": {
            "speed": 2.5,
            "HP": 80,
            "maxHP":560
        }

    }

}